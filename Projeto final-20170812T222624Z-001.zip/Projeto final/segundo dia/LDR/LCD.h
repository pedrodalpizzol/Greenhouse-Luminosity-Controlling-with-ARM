
void lcd_init(void);
void lcd_delay(int us);
void lcd_write_command(unsigned int command);
void lcd_write_data(unsigned int data);
void lcd_write_message(char * data);
void lcd_set_pointer(unsigned char x,unsigned char y);
