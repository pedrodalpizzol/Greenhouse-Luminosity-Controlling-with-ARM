#include "MKL25Z4.h"


void lcd_init(void);
void lcd_delay(int us);
void lcd_write_command(unsigned char command);
void lcd_write_data(unsigned char data);
void inicPorts(void);
//void lcd_set_pointer()
void lcd_write_message(char * data);
void enable(void);
void lcd_set_pointer(unsigned char x,unsigned char y);

void lcd_init(void){
inicPorts();
lcd_write_command(0x38);
lcd_write_command(0x38);
lcd_write_command(0x0C);//cursor apagado
lcd_write_command(0x06);//deslocamento autom�tico HABILITADO, incremento habilitado
lcd_write_command(0x01);
lcd_delay(1600);
}

void inicPorts(void){
SIM_SCGC5 = (1 << 13) + (1 << 10);			//habilitar o clock das portas
	
GPIOB_PDDR = (1 << 8) + (1 << 9) + (1 << 10) + (1 << 11);												//estes pinos ser�o sa�da no porta B
GPIOE_PDDR = (1 << 2) + (1 << 3) + (1 << 4) + (1 << 5) + (1 << 23) + (1 << 29);	//estes pinos ser�o sa�da no porta E



PORTB_PCR8 = 0x00000103;																												//configura todas as portas como GPIO
PORTB_PCR9 = 0x00000103;
PORTB_PCR10 = 0x00000103;
PORTB_PCR11 = 0x00000103;
PORTE_PCR2 = 0x00000103;
PORTE_PCR3 = 0x00000103;
PORTE_PCR4 = 0x00000103;
PORTE_PCR5 = 0x00000103;
PORTE_PCR23 = 0x00000103;  //E
PORTE_PCR29 = 0x00000103;	 //RS
}



void lcd_delay(int us){
		//configurar periodic interrupt timer (chapter 32 datasheet)
		//habilitar o timer
		SIM_SCGC6 |= (1<<23);	//habilitar o PIT
		PIT_MCR = 0; 					//MDIR  = FRZ = 0
		PIT_LDVAL0 = us*10; 		//para 40us de delay
		PIT_TCTRL0 = 1;				//TEN = 1 liga o timer
		while(!PIT_TFLG0);
		PIT_TCTRL0 = 0; 			//TEN = 0  desabilita o timer
		PIT_TFLG0 = 1;				//zera a flag de interrup��o
}

void enable(void){
	GPIOE_PSOR |= (1 << 23);
	GPIOE_PCOR |= (1 << 23);
}
void lcd_write_data(unsigned char data){
	GPIOB_PCOR = ((0x0F) << 8);
	GPIOE_PCOR = ((0xF0) >> 2);
	GPIOB_PSOR = ((0x0F & data) << 8);
	GPIOE_PSOR = ((0xF0 & data) >> 2); //como as vari�veis est�o nos 4 MSB, preciso deslocar para a direita
	GPIOE_PSOR = (1 << 29);
	//sinal de enable
	enable();
	lcd_delay(40);
}

void lcd_write_command(unsigned char command){
	GPIOB_PCOR = ((0x0F) << 8);
	GPIOE_PCOR = ((0xF0) >> 2);
	GPIOB_PSOR = ((0x0F & command) << 8);
	GPIOE_PSOR = ((0xF0 & command) >> 2); //como as vari�veis est�o nos 4 MSB, preciso deslocar para a direita
	GPIOE_PCOR = (1 << 29);
	//sinal de enable
	enable();
	lcd_delay(40);
}

void lcd_write_message(char * data){

	char i=0;
	while(*(data+i)){
	lcd_write_data(*(data+i));
	i++;
	}
}

void lcd_set_pointer(unsigned char x,unsigned char y){
char place = 0;
place = x;
place = place + (1 << 7);
y--;
place = place + (y << 6);
lcd_write_command (place);
}

