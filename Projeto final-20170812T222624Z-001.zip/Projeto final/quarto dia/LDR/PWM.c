#include "MKL25Z4.h"

void PWM_init(void);
void set_PWM(unsigned int value);

void PWM_init(void){
	//habilita o clock da porta
	SIM_SCGC5|= (1 << 13);
	//DIZ QUE ELA � SA�DA
	GPIOE_PDDR |=(1<<30);
	//inicializa-o em modo PWM
	PORTE_PCR30 |= 0x00000303;
	//inicializa o PWM na porta E30
	//seleciona a fonte de clock
	SIM_SOPT2 |= (1 << 24);
	//TIPO DE CLOCK
	SIM_SCGC6 |= (1 << 24);
	//agora, configuramos o clock mode selection para incrementar a cada 128 pulso de clock (COM PRESCALE)
	
	TPM0_C3SC |= 0x2C;
	//DUTY CYCLE
	TPM0_MOD = 50000;
	//LOW TIME
	TPM0_C3V = 25000;
	
	TPM0_SC |= 0xf;
}

void set_PWM(unsigned int value){

TPM0_C3V = value;

}
