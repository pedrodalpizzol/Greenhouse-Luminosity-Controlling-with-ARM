#include "MKL25Z4.h"
#include "LCD.h"
#include "PWM.h"
#include "stdfunc.h"

#define BOT_SUP 21
#define BOT_INF 22

void select_planta(unsigned char k);
void setup(void);

int msecond_counter;
int second_counter;
int minute_counter;
int hour_counter;
int switch_config=0; 
int planta_atual=1;
void lcd_print_n_digits(int value,unsigned char x, unsigned char y);
void update_routine(void);

char plantas[8][14] = {  
   {"Asplenio      "} ,   /*  initializers for row indexed by 0 */
   {"Azaleia       "} ,   /*  initializers for row indexed by 1 */
   {"Bromelia      "} , 
   {"Camedoria     "} , 
   {"Camelia       "} ,
   {"Cannabis      "} ,   
   {"Dracenas      "} ,  
   {"Mini Samambaia"} ,    
};
char planta[14];

int main (void){
		
	setup();

while(1){

		switch_config = switch_config_set(BOT_INF); //detecta varia��o do bot�o inferior e altera o status quo
	switch(switch_config){
		case 0: //estado inicial
		update_routine();
			/*
		
				PRECISAMOS FAZER UMA FUN��O QUE FICA ATUALIZANDO O HOR�RIO NO DISPLAY ENQUANTO N�O ESTIVERMOS
				CONFIFURANDO O SISTEMA
		
				-LEMBRAR DE MOSTRAR A LEITURA DO SENSOR E A REFER�NCIA
				-ALTERAR O TIMER DE TEMPO REAL, POIS O MINUTO EST� PASSANDO EM TEMPO DE SEGUNDO
				-CRIAR O VETOR DE VALORES DE REFER�NCIAS DO PID
				-IMPLEMENTAR O PID
				
			*/
		break;
		case 1: //configurando planta
			planta_atual = config_data_set(8,planta_atual);
			select_planta(planta_atual);
			lcd_set_pointer(0,1);
			lcd_write_message(planta);
		break;
		case 2: //configurando hora
			lcd_set_pointer(2,2);
			lcd_write_data(':');
			hour_counter = config_data_set(24,hour_counter);
			lcd_print_n_digits(hour_counter,1,2);
		break;
		case 3: //configurando minuto
			minute_counter = config_data_set(60,minute_counter);
			lcd_print_n_digits(minute_counter,4,2);
		break;
	}
		
	
}			
}

void setup(void){
SystemCoreClockUpdate();
lcd_init();
PWM_init();
butt_init();
ADC_init();
PIT_init();
}

void PIT_IRQHandler(void){
	
	ADCValue = ADC0_RA;					//salva em ADCValue a �ltima convers�o que foi feita
	ADC0_SC1A = 0x0000000;				//inicia uma convers�o AD para ser lida na pr�xima interrup��o
	
	
	msecond_counter++; //passou 50ms
	if(msecond_counter==20){
	second_counter++; //passou 1 segundo
	msecond_counter=0;
	}
	if(second_counter==60){
	minute_counter++;
	second_counter=0;	
	}
	if(minute_counter==60){
	hour_counter++;
	minute_counter=0;	
	}
	if(hour_counter==24){
	hour_counter=0;
	}	
PIT_TFLG1 = 1;						//limpa o flag do PIT
}


void select_planta(unsigned char k){
	for (int i = 0; i < 14; i++) {
		planta[i] = plantas[k][i];
	}

}

void lcd_print_n_digits(int value,unsigned char x, unsigned char y) {
	if (value == 0){
	x--;
	lcd_set_pointer(x,y);
	lcd_write_data('0');
	lcd_write_data('0');
	}
	else {
while (value > 0) {
	int digit = value % 10;
	lcd_set_pointer(x,y);
	lcd_write_data('0' + digit);
	x--;
	value /= 10;
}
}
}

void update_routine(void){
lcd_set_pointer(0,1);
		lcd_write_message(planta);
		lcd_print_n_digits(hour_counter,1,2);
		lcd_set_pointer(2,2);
		lcd_write_data(':');
		lcd_print_n_digits(minute_counter,4,2);
		lcd_delay(100);


}
