#include "MKL25Z4.h"

extern unsigned int ADCValue;

void butt_init(void);
void ADC_init(void);
void PIT_init(void);
int switch_config_set(unsigned char pin);
int config_data_set(int possibilidades,int variavel_atual);
