#include "MKL25Z4.h"

#define BOT_SUP 21
#define BOT_INF 22

int counter_bot_sup=0;
unsigned int ADCValue = 0;
void butt_init(void);
int config_data_set(int possibilidades,int variavel_atual);
int switch_config_set(unsigned char pin);
void ADC_init(void);
void PIT_init(void);
char auxsup=1;
int counter_bot_inf=0;
char auxinf=1;


void butt_init(void){
// os bot�es B1 e B2 est�o ligados nas portas E 21/22, respectivamente
// a ideia seria ler essa fun��o dentro da main sempre
// ela atualiza o valor de 2 vari�veis globais que indicar�o tipo de planta e hora
// se os bot�es forem pressionados incrementam a vari�vel auxiliar
// para isso devemos estabelecer que a porta ser� entrada, digital

	SIM_SCGC5|= (1 << 13); 				//habilita o clock da porta
    PORTE_PCR21 = 0x00000112; 			//portas como GPIO e com os resistores 
    PORTE_PCR22 = 0x00000112; 			//pull up/down internos ativados
}

int switch_config_set(unsigned char pin){
/*
	ESTA FUN��O ALTERA O ESTADO ATUAL DO PROGRAMA (CONFIGURA��O OU OPERA��O NORMAL).
	A SUA ENTRADA � O PINO DE SELE��O DE ESTADOS E A SUA SA�DA E O ESTADO ATUALIZADO SE FOR DETECTADO QUE O BOT�O FOI
	PRESSIONADO
*/
	
    if((!(GPIOE_PDIR & (1<<pin)))&(auxsup)){
    counter_bot_sup++;
	if(counter_bot_sup==4){
	counter_bot_sup=0;	
	}
	auxsup=0;	
}
	if((GPIOE_PDIR & (1<<pin))){
	auxsup=1;
	}
	return counter_bot_sup;
}

int config_data_set(int possibilidades,int variavel_atual){
/*
	ESTA FUN��O ALTERA O VALOR DO �NDICE DAS PLANTAS, O VALOR DOS MINUTOS E O VALOR DOS SEGUNDOS.
	A SUA ENTRADA � O N�MERO DE POSSIBILIDADES QUE CADA VARI�VEL PODE ASSUMIR E O VALOR QUE ELA POSSUI ANTES DE SER
	CONFIGURADA.
	A SUA SA�DA � A VARI�VEL ATUALIZADA
*/	
	
	counter_bot_inf=variavel_atual;
    if((!(GPIOE_PDIR & (1<<BOT_SUP)))&(auxinf)){
    counter_bot_inf++;
	if(counter_bot_inf==possibilidades){
	counter_bot_inf=0;	
	}
	auxinf=0;	
}
	if((GPIOE_PDIR & (1<<BOT_SUP))){
	auxinf=1;
	}
	return counter_bot_inf;
}

void ADC_init(void){
	
	SIM_SCGC6 |= (1 << 27);				//habilita o clock do PIT
	ADC0_CFG1 = 0x4; 					//configura o ADC em short-time, 12bits, bus clock
	ADC0_SC1A = 0x0000000;				//come�a a primeira convers�o para ser lida na primeira interrup��o
}

void PIT_init(void){
	
	SIM_SCGC6 |= (1<<23);				//habilitar o PIT
	PIT_MCR = 0; 						//MDIR  = FRZ = 0 /faz o clock do PIT funcionar
	PIT_LDVAL1 = 5000; 					//para 50ms entre as interrup��es
	PIT_TCTRL1 = 3;						//TEN = 1 liga o timer
	NVIC_EnableIRQ(PIT_IRQn);			//habilita as interrup��es de PIT no PIT1

}



