#include "MKL25Z4.h"

void PWM_init(void);
void set_PWM(unsigned int value);
